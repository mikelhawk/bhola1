package com.qnally.shappapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class RegistrationPayment extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_payment);
    }
}
